﻿
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;

namespace $rootnamespace$
{

public class $safeitemrootname$EntityTypeConfiguration: IEntityTypeConfiguration<$safeitemrootname$>
{
    public void Configure(EntityTypeBuilder<$safeitemrootname$> builder)
    {
        throw new NotImplementedException();
    }
}
}
